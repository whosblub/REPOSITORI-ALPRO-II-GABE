import tkinter as tk
from tkinter import messagebox, filedialog
from PIL import Image, ImageTk
import mysql.connector
from mysql.connector import Error
import hashlib
import os
import shutil
from pathlib import Path
from kantin_extensions import KantinExtensions

class KantinApp:
    def __init__(self, root):
        self.root = root
        self.root.title("PESENIN DIGIDAW - Login Penjual")
        self.root.geometry("600x600")
        self.root.configure(bg="#2c3e50")

        self.init_database()
        self.image_refs = []  # menyimpan referensi gambar
        self.extensions = KantinExtensions(self)
        self.show_login_form()

    def init_database(self):
        try:
            self.conn = mysql.connector.connect(
                host='localhost',
                user='root',
                password='',
                database='kantin_online'
            )
            self.cursor = self.conn.cursor()

        except Error as e:
            messagebox.showerror("Database Error", f"Gagal koneksi ke database: {e}")
            self.root.destroy()

    def hash_password(self, password):
        return hashlib.sha256(password.encode()).hexdigest()

    def show_login_form(self):
        self.clear_window()
        tk.Label(self.root, text="Login Penjual", font=("Helvetica", 18, "bold"), fg="white", bg="#2c3e50").pack(pady=20)

        tk.Label(self.root, text="Username", fg="white", bg="#2c3e50").pack()
        self.login_username = tk.Entry(self.root)
        self.login_username.pack(pady=5)

        tk.Label(self.root, text="Password", fg="white", bg="#2c3e50").pack()
        self.login_password = tk.Entry(self.root, show="*")
        self.login_password.pack(pady=5)

        tk.Button(self.root, text="Login", command=self.login_user, bg="#27ae60", fg="white").pack(pady=10)
        tk.Button(self.root, text="Belum punya akun? Register", command=self.show_register_form, bg="#2980b9", fg="white").pack(pady=5)
        tk.Button(self.root, text="Masuk sebagai Pembeli", command=self.show_buyer_view, bg="#8e44ad", fg="white").pack(pady=10)

    def show_register_form(self):
        self.clear_window()
        tk.Label(self.root, text="Register Penjual", font=("Helvetica", 18, "bold"), fg="white", bg="#2c3e50").pack(pady=20)

        tk.Label(self.root, text="Nama Penjual", fg="white", bg="#2c3e50").pack()
        self.reg_seller_name = tk.Entry(self.root)
        self.reg_seller_name.pack(pady=5)

        tk.Label(self.root, text="Nama Toko", fg="white", bg="#2c3e50").pack()
        self.reg_store_name = tk.Entry(self.root)
        self.reg_store_name.pack(pady=5)

        tk.Label(self.root, text="Username", fg="white", bg="#2c3e50").pack()
        self.reg_username = tk.Entry(self.root)
        self.reg_username.pack(pady=5)

        tk.Label(self.root, text="Password", fg="white", bg="#2c3e50").pack()
        self.reg_password = tk.Entry(self.root, show="*")
        self.reg_password.pack(pady=5)

        tk.Label(self.root, text="Gambar Kantin (opsional)", fg="white", bg="#2c3e50").pack()
        self.reg_image_path = tk.Entry(self.root)
        self.reg_image_path.pack(pady=5)
        tk.Button(self.root, text="Pilih Gambar", command=self.browse_image, bg="#f39c12", fg="white").pack(pady=5)

        tk.Button(self.root, text="Daftar", command=self.register_user, bg="#27ae60", fg="white").pack(pady=10)
        tk.Button(self.root, text="Sudah punya akun? Login", command=self.show_login_form, bg="#2980b9", fg="white").pack(pady=5)

    def browse_image(self):
        file_path = filedialog.askopenfilename(filetypes=[["Image files", "*.jpg *.png *.jpeg"]])
        if file_path:
            self.reg_image_path.delete(0, tk.END)
            self.reg_image_path.insert(0, file_path)

    def register_user(self):
        seller_name = self.reg_seller_name.get().strip()
        store_name = self.reg_store_name.get().strip()
        username = self.reg_username.get().strip()
        password = self.reg_password.get().strip()
        image_path = self.reg_image_path.get().strip()

        if not seller_name or not store_name or not username or not password:
            messagebox.showerror("Error", "Semua field wajib diisi!")
            return

        hashed_pw = self.hash_password(password)

        saved_image_path = ""
        if image_path and os.path.exists(image_path):
            try:
                images_dir = os.path.join(os.getcwd(), "images")
                os.makedirs(images_dir, exist_ok=True)
                
                # Generate unique filename untuk menghindari konflik
                filename = os.path.basename(image_path)
                name, ext = os.path.splitext(filename)
                counter = 1
                while os.path.exists(os.path.join(images_dir, filename)):
                    filename = f"{name}_{counter}{ext}"
                    counter += 1
                
                full_save_path = os.path.join(images_dir, filename)
                shutil.copy(image_path, full_save_path)
                saved_image_path = f"images/{filename}"  # Path relatif konsisten
                
            except Exception as e:
                messagebox.showerror("Gagal Simpan Gambar", f"Gagal menyalin gambar: {e}")
                return

        try:
            self.cursor.execute('''
                INSERT INTO sellers (seller_name, store_name, username, password, image_path)
                VALUES (%s, %s, %s, %s, %s)
            ''', (seller_name, store_name, username, hashed_pw, saved_image_path))
            self.conn.commit()
            messagebox.showinfo("Sukses", "Registrasi berhasil! Silakan login.")
            self.show_login_form()
        except Error as e:
            if "Duplicate entry" in str(e):
                messagebox.showerror("Error", "Username sudah digunakan! Pilih username lain.")
            else:
                messagebox.showerror("Database Error", f"Gagal registrasi: {e}")

    def login_user(self):
        username = self.login_username.get().strip()
        password = self.login_password.get()

        if not username or not password:
            messagebox.showerror("Error", "Harap isi semua field!")
            return

        hashed_password = self.hash_password(password)

        try:
            self.cursor.execute('''
                SELECT id, seller_name, store_name, username, password, image_path, created_at 
                FROM sellers WHERE username = %s AND password = %s
            ''', (username, hashed_password))
            user = self.cursor.fetchone()

            if user:
                messagebox.showinfo("Sukses", f"Selamat datang, {user[1]}!")
                self.show_main_dashboard(user)
            else:
                messagebox.showerror("Login Gagal", "Username atau password salah.")

        except Error as e:
            messagebox.showerror("Database Error", f"Kesalahan: {e}")

    def display_image(self, image_path, size=(200, 200)):
        """Helper method untuk menampilkan gambar dengan error handling yang lebih robust"""
        if not image_path or image_path.strip() == "":
            return None
            
        # Coba berbagai cara untuk mendapatkan path yang benar
        possible_paths = [
            image_path,  # Path asli dari database
            os.path.join(os.getcwd(), image_path),  # Path relatif dari current directory
            os.path.join(os.path.dirname(os.path.abspath(__file__)), image_path),  # Path relatif dari script
            os.path.abspath(image_path)  # Path absolut
        ]
        
        for path_attempt in possible_paths:
            try:
                if os.path.exists(path_attempt):
                    print(f"Loading image from: {path_attempt}")  # Debug info
                    img = Image.open(path_attempt)
                    img = img.resize(size, Image.Resampling.LANCZOS)
                    photo = ImageTk.PhotoImage(img)
                    self.image_refs.append(photo)  # Simpan referensi untuk mencegah garbage collection
                    return photo
            except Exception as e:
                print(f"Failed to load image from {path_attempt}: {e}")
                continue
        
        return None

    def show_main_dashboard(self, user):
        self.extensions.show_seller_dashboard(user)

    def show_buyer_view(self):
        self.extensions.show_buyer_mode_all_sellers()

    def clear_window(self):
        for widget in self.root.winfo_children():
            widget.destroy()

if __name__ == "__main__":
    root = tk.Tk()
    app = KantinApp(root)
    root.mainloop()