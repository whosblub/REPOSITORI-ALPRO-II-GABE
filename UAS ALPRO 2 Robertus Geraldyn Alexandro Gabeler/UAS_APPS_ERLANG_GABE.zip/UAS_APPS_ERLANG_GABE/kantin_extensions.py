import tkinter as tk
from tkinter import ttk, messagebox, simpledialog
from datetime import datetime, timedelta
import json
import os
from mysql.connector import Error
from PIL import Image, ImageTk

class KantinExtensions:
    def __init__(self, main_app):
        self.main_app = main_app
        self.root = main_app.root
        self.clear_screen = main_app.clear_window
        self.current_user = None
        self.current_seller_id = None
        self.cart = {}
        self.init_additional_tables()

    def init_additional_tables(self):
        """Initialize additional tables for enhanced features"""
        try:
            # Table untuk menu dengan fitur diskon
            self.main_app.cursor.execute('''
                CREATE TABLE IF NOT EXISTS menu_items (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    seller_id INT,
                    nama VARCHAR(255) NOT NULL,
                    harga INT NOT NULL,
                    stok INT DEFAULT 0,
                    diskon INT DEFAULT 0,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    FOREIGN KEY (seller_id) REFERENCES sellers(id) ON DELETE CASCADE
                )
            ''')

            # Table untuk pesanan dengan sistem pre-order
            self.main_app.cursor.execute('''
                CREATE TABLE IF NOT EXISTS orders (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    pembeli_nama VARCHAR(255) NOT NULL,
                    seller_id INT,
                    menu_items JSON,
                    catatan TEXT,
                    tanggal_ambil DATE,
                    jam_ambil TIME,
                    total_harga INT,
                    status ENUM('pending', 'ready', 'completed') DEFAULT 'pending',
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    FOREIGN KEY (seller_id) REFERENCES sellers(id) ON DELETE CASCADE
                )
            ''')

            # Update table sellers untuk jam operasional
            self.main_app.cursor.execute('''
                ALTER TABLE sellers 
                ADD COLUMN IF NOT EXISTS jam_buka TIME DEFAULT '08:00:00',
                ADD COLUMN IF NOT EXISTS jam_tutup TIME DEFAULT '17:00:00'
            ''')

            self.main_app.conn.commit()
            print("Additional tables initialized successfully")

        except Error as e:
            print(f"Error initializing additional tables: {e}")

    def show_seller_dashboard(self, user):
        """Enhanced seller dashboard with integrated features"""
        self.current_user = user
        self.current_seller_id = user[0]
        self.main_app.clear_window()

        main_frame = tk.Frame(self.main_app.root, bg="#2c3e50")
        main_frame.pack(fill="both", expand=True, padx=20, pady=20)

        # Header with store info
        header_frame = tk.Frame(main_frame, bg="#34495e", relief="raised", bd=2)
        header_frame.pack(fill="x", pady=(0, 20))

        tk.Label(header_frame, text=f"Dashboard - {user[2]}", 
                font=("Arial", 18, "bold"), fg="white", bg="#34495e").pack(pady=10)
        tk.Label(header_frame, text=f"Pemilik: {user[1]}", 
                font=("Arial", 12), fg="white", bg="#34495e").pack(pady=(0, 10))

        # Display store image if available
        if user[5] and user[5].strip():  # image_path
            photo = self.main_app.display_image(user[5], (150, 100))
            if photo:
                tk.Label(header_frame, image=photo, bg="#34495e").pack(pady=5)

        # Check for new orders notification
        new_orders_count = self.get_new_orders_count()
        notif_text = f" ({new_orders_count} baru)" if new_orders_count > 0 else ""

        # Menu buttons
        btn_frame = tk.Frame(main_frame, bg="#2c3e50")
        btn_frame.pack(expand=True)

        tk.Button(btn_frame, text=f"📦 Lihat Pesanan{notif_text}", font=("Arial", 14), 
                 width=20, bg="#3498db", fg="white", 
                 command=self.show_orders_management).pack(pady=10)
        
        tk.Button(btn_frame, text="🍽 Kelola Menu", font=("Arial", 14), 
                 width=20, bg="#27ae60", fg="white",
                 command=self.show_menu_management).pack(pady=10)
        
        tk.Button(btn_frame, text="🏪 Edit Toko", font=("Arial", 14), 
                 width=20, bg="#f39c12", fg="white",
                 command=self.show_store_settings).pack(pady=10)
        
        tk.Button(btn_frame, text="🚪 Logout", font=("Arial", 12), 
                 width=15, bg="#e74c3c", fg="white",
                 command=self.main_app.show_login_form).pack(pady=20)

    def get_new_orders_count(self):
        """Get count of new orders for current seller"""
        try:
            self.main_app.cursor.execute('''
                SELECT COUNT(*) FROM pesanan 
                WHERE seller_id = %s AND status = 'pending'
                AND DATE(created_at) = CURDATE()
            ''', (self.current_seller_id,))
            return self.main_app.cursor.fetchone()[0]
        except:
            return 0

    def show_menu_management(self):
        """Enhanced menu management with discount features"""
        self.main_app.clear_window()
        
        main_frame = tk.Frame(self.main_app.root, bg="#2c3e50")
        main_frame.pack(fill="both", expand=True, padx=20, pady=20)
        
        tk.Label(main_frame, text="Kelola Menu", font=("Arial", 18, "bold"), 
                fg="white", bg="#2c3e50").pack(pady=10)
        
        # Menu list frame with scrollbar
        list_frame = tk.Frame(main_frame, bg="#34495e")
        list_frame.pack(fill="both", expand=True, pady=10)
        
        canvas = tk.Canvas(list_frame, bg="#34495e")
        scrollbar = ttk.Scrollbar(list_frame, orient="vertical", command=canvas.yview)
        scrollable_frame = tk.Frame(canvas, bg="#34495e")
        
        scrollable_frame.bind(
            "<Configure>",
            lambda e: canvas.configure(scrollregion=canvas.bbox("all"))
        )
        
        canvas.create_window((0, 0), window=scrollable_frame, anchor="nw")
        canvas.configure(yscrollcommand=scrollbar.set)
        
        # Load and display menu items
        self.load_menu_items(scrollable_frame)
        
        canvas.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")
        
        # Control buttons
        btn_frame = tk.Frame(main_frame, bg="#2c3e50")
        btn_frame.pack(fill="x", pady=10)
        
        tk.Button(btn_frame, text="➕ Tambah Menu", font=("Arial", 12), 
                 bg="#27ae60", fg="white", command=self.add_menu_item).pack(side="right", padx=5)
        tk.Button(btn_frame, text="← Kembali", font=("Arial", 12), 
                 bg="#95a5a6", fg="white", 
                 command=lambda: self.show_seller_dashboard(self.current_user)).pack(side="left", padx=5)

    def load_menu_items(self, parent):
        """Load and display menu items for current seller"""
        try:
            self.main_app.cursor.execute('''
                SELECT id, nama, harga, stok, diskon 
                FROM menu_items WHERE seller_id = %s
                ORDER BY diskon DESC, nama ASC
            ''', (self.current_seller_id,))
            
            menu_items = self.main_app.cursor.fetchall()
            
            if not menu_items:
                tk.Label(parent, text="Belum ada menu. Tambahkan menu pertama Anda!", 
                        font=("Arial", 12), fg="white", bg="#34495e").pack(pady=20)
            else:
                for item in menu_items:
                    self.create_menu_item_widget(parent, item)
                    
        except Error as e:
            messagebox.showerror("Database Error", f"Gagal memuat menu: {e}")

    def create_menu_item_widget(self, parent, item):
        """Create widget for each menu item"""
        item_frame = tk.Frame(parent, bg="#ecf0f1", relief="raised", bd=2)
        item_frame.pack(fill="x", pady=5, padx=10)

        # Menu info
        info_frame = tk.Frame(item_frame, bg="#ecf0f1")
        info_frame.pack(side="left", fill="x", expand=True, padx=10, pady=5)

        nama = item[1]
        if item[4] > 0:  # diskon
            nama += f" ({item[4]}% OFF)"

        tk.Label(info_frame, text=nama, font=("Arial", 12, "bold"), 
                bg="#ecf0f1").pack(anchor="w")

        harga_asli = item[2]
        if item[4] > 0:
            harga_diskon = int(harga_asli * (100 - item[4]) / 100)
            tk.Label(info_frame, text=f"Rp {harga_asli:,} → Rp {harga_diskon:,}", 
                    font=("Arial", 10), bg="#ecf0f1", fg="#e74c3c").pack(anchor="w")
        else:
            tk.Label(info_frame, text=f"Rp {harga_asli:,}", 
                    font=("Arial", 10), bg="#ecf0f1").pack(anchor="w")

        tk.Label(info_frame, text=f"Stok: {item[3]}", 
                font=("Arial", 9), bg="#ecf0f1", fg="gray").pack(anchor="w")

        # Control buttons
        ctrl_frame = tk.Frame(item_frame, bg="#ecf0f1")
        ctrl_frame.pack(side="right", padx=10, pady=5)

        tk.Button(ctrl_frame, text="✏ Edit", width=8, bg="#3498db", fg="white",
                 command=lambda: self.edit_menu_item(item[0])).pack(side="left", padx=2)
        tk.Button(ctrl_frame, text="🗑 Hapus", width=8, bg="#e74c3c", fg="white",
                 command=lambda: self.delete_menu_item(item[0])).pack(side="left", padx=2)

    def add_menu_item(self):
        """Add new menu item dialog"""
        self.menu_item_dialog("Tambah Menu Baru")

    def edit_menu_item(self, menu_id):
        """Edit existing menu item"""
        try:
            self.main_app.cursor.execute('''
                SELECT nama, harga, stok, diskon 
                FROM menu_items WHERE id = %s
            ''', (menu_id,))
            item = self.main_app.cursor.fetchone()
            if item:
                self.menu_item_dialog("Edit Menu", menu_id, item)
        except Error as e:
            messagebox.showerror("Database Error", f"Gagal memuat data menu: {e}")

    def menu_item_dialog(self, title, menu_id=None, existing_data=None):
        """Universal dialog for add/edit menu item"""
        dialog = tk.Toplevel(self.main_app.root)
        dialog.title(title)
        dialog.geometry("400x350")
        dialog.configure(bg="#2c3e50")
        dialog.grab_set()

        tk.Label(dialog, text=title, font=("Arial", 16, "bold"), 
                fg="white", bg="#2c3e50").pack(pady=20)

        # Form fields
        fields = {}
        field_names = [("nama", "Nama Menu"), ("harga", "Harga"), ("stok", "Stok"), ("diskon", "Diskon (%)")]

        for field_key, field_label in field_names:
            tk.Label(dialog, text=field_label, fg="white", bg="#2c3e50").pack(anchor="w", padx=20, pady=(10,0))
            entry = tk.Entry(dialog, width=30)
            entry.pack(padx=20, pady=5)
            fields[field_key] = entry

            # Set existing values if editing
            if existing_data:
                if field_key == "nama":
                    entry.insert(0, existing_data[0])
                elif field_key == "harga":
                    entry.insert(0, str(existing_data[1]))
                elif field_key == "stok":
                    entry.insert(0, str(existing_data[2]))
                elif field_key == "diskon":
                    entry.insert(0, str(existing_data[3]))

        def save_menu():
            try:
                nama = fields["nama"].get().strip()
                harga = int(fields["harga"].get())
                stok = int(fields["stok"].get())
                diskon_str = fields["diskon"].get().strip()

                if not diskon_str:
                    diskon = 0
                else:
                    try:
                        diskon = int(diskon_str)
                    except ValueError:
                        messagebox.showerror("Error", "Diskon harus berupa angka.")
                        return

                if not nama:
                    raise ValueError("Nama menu harus diisi")
                if harga <= 0:
                    raise ValueError("Harga harus lebih dari 0")
                if stok < 0:
                    raise ValueError("Stok tidak boleh negatif")
                if diskon < 0 or diskon > 100:
                    raise ValueError("Diskon harus antara 0-100%")

                if menu_id:  # Edit existing
                    self.main_app.cursor.execute('''
                        UPDATE menu_items SET nama=%s, harga=%s, stok=%s, diskon=%s
                        WHERE id=%s AND seller_id=%s
                    ''', (nama, harga, stok, diskon, menu_id, self.current_seller_id))
                    success_msg = "Menu berhasil diupdate!"
                else:  # Add new
                    self.main_app.cursor.execute('''
                        INSERT INTO menu_items (seller_id, nama, harga, stok, diskon)
                        VALUES (%s, %s, %s, %s, %s)
                    ''', (self.current_seller_id, nama, harga, stok, diskon))
                    success_msg = "Menu berhasil ditambahkan!"

                self.main_app.conn.commit()
                messagebox.showinfo("Sukses", success_msg)
                dialog.destroy()
                self.show_menu_management()

            except ValueError as e:
                messagebox.showerror("Error", str(e))
            except Error as e:
                messagebox.showerror("Database Error", f"Gagal menyimpan menu: {e}")

        tk.Button(dialog, text="💾 Simpan", command=save_menu, 
                 bg="#27ae60", fg="white", font=("Arial", 12)).pack(pady=20)

    def delete_menu_item(self, menu_id):
        """Delete menu item with confirmation"""
        if messagebox.askyesno("Konfirmasi", "Yakin ingin menghapus menu ini?"):
            try:
                self.main_app.cursor.execute('''
                    DELETE FROM menu_items WHERE id = %s AND seller_id = %s
                ''', (menu_id, self.current_seller_id))
                self.main_app.conn.commit()
                messagebox.showinfo("Sukses", "Menu berhasil dihapus!")
                self.show_menu_management()
            except Error as e:
                messagebox.showerror("Database Error", f"Gagal menghapus menu: {e}")

    def show_orders_management(self):
        """Show orders management with grouping by pickup time"""
        self.main_app.clear_window()
        
        main_frame = tk.Frame(self.main_app.root, bg="#2c3e50")
        main_frame.pack(fill="both", expand=True, padx=20, pady=20)
        
        tk.Label(main_frame, text="Daftar Pesanan", font=("Arial", 18, "bold"), 
                fg="white", bg="#2c3e50").pack(pady=10)
        
        # Orders list with scrollbar
        list_frame = tk.Frame(main_frame, bg="#34495e")
        list_frame.pack(fill="both", expand=True, pady=10)
        
        canvas = tk.Canvas(list_frame, bg="#34495e")
        scrollbar = ttk.Scrollbar(list_frame, orient="vertical", command=canvas.yview)
        scrollable_frame = tk.Frame(canvas, bg="#34495e")
        
        scrollable_frame.bind(
            "<Configure>",
            lambda e: canvas.configure(scrollregion=canvas.bbox("all"))
        )
        
        canvas.create_window((0, 0), window=scrollable_frame, anchor="nw")
        canvas.configure(yscrollcommand=scrollbar.set)
        
        # Load and display orders
        self.load_orders(scrollable_frame)
        
        canvas.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")
        
        # Back button
        tk.Button(main_frame, text="← Kembali", font=("Arial", 12), 
                 bg="#95a5a6", fg="white", 
                 command=lambda: self.show_seller_dashboard(self.current_user)).pack(pady=10)

    def load_orders(self, parent):
        for pesanan in self.data["pesanan"]:
            if str(pesanan["toko_id"]) == str(self.current_seller_id):
                frame = tk.Frame(parent, bg="#ecf0f1", bd=2, relief="groove")
                frame.pack(fill="x", padx=10, pady=5)

                tk.Label(frame, text=f"Pembeli: {pesanan['pembeli']}", bg="#ecf0f1", anchor="w", font=("Arial", 10, "bold")).pack(fill="x")
                tk.Label(frame, text=f"Tanggal: {pesanan['tanggal_ambil']} {pesanan['jam_ambil']}", bg="#ecf0f1", anchor="w").pack(fill="x")
                tk.Label(frame, text=f"Catatan: {pesanan['catatan']}", bg="#ecf0f1", anchor="w").pack(fill="x")
                tk.Label(frame, text=f"Status: {pesanan['status']}", bg="#ecf0f1", anchor="w").pack(fill="x")

                # Detail menu
                menu_detail = ""
                for menu_id, qty in pesanan["menu"].items():
                    menu = self.data["menu"].get(menu_id)
                    if menu:
                        menu_detail += f"- {menu['nama']} x{qty}\n"

                if menu_detail:
                    tk.Label(frame, text=menu_detail.strip(), bg="#ecf0f1", anchor="w", justify="left").pack(fill="x", pady=(5, 0))

    def create_order_widget(self, parent, order):
        """Create widget for individual order"""
        order_frame = tk.Frame(parent, bg="#ecf0f1", relief="groove", bd=2)
        order_frame.pack(fill="x", pady=2, padx=20)

        # Order header
        header_frame = tk.Frame(order_frame, bg="#ecf0f1")
        header_frame.pack(fill="x", padx=10, pady=5)

        tk.Label(header_frame, text=f"👤 {order[1]} | ⏰ {order[5]}", 
                font=("Arial", 11, "bold"), bg="#ecf0f1").pack(side="left")

        status_color = {"pending": "#f39c12", "ready": "#27ae60", "completed": "#95a5a6"}
        tk.Label(header_frame, text=order[7].upper(), 
                font=("Arial", 10, "bold"), bg="#ecf0f1", 
                fg=status_color.get(order[7], "#2c3e50")).pack(side="right")

        # Menu items
        try:
            menu_items = json.loads(order[2]) if order[2] else {}
            for menu_id, qty in menu_items.items():
                # Get menu name
                self.main_app.cursor.execute('SELECT nama FROM menu_items WHERE id = %s', (menu_id,))
                menu_result = self.main_app.cursor.fetchone()
                menu_name = menu_result[0] if menu_result else f"Menu ID {menu_id}"
                
                tk.Label(order_frame, text=f"  • {menu_name} x{qty}", 
                        font=("Arial", 9), bg="#ecf0f1").pack(anchor="w", padx=15)
        except:
            tk.Label(order_frame, text="  • Error loading menu items", 
                    font=("Arial", 9), bg="#ecf0f1", fg="red").pack(anchor="w", padx=15)

        # Notes and total
        if order[3]:  # catatan
            tk.Label(order_frame, text=f"  📝 {order[3]}", 
                    font=("Arial", 9), bg="#ecf0f1", fg="gray").pack(anchor="w", padx=15)

        tk.Label(order_frame, text=f"💰 Total: Rp {order[6]:,}", 
                font=("Arial", 10, "bold"), bg="#ecf0f1", fg="#27ae60").pack(anchor="w", padx=15, pady=(0,5))

    def show_store_settings(self):
        """Show store settings dialog"""
        dialog = tk.Toplevel(self.main_app.root)
        dialog.title("Pengaturan Toko")
        dialog.geometry("500x400")
        dialog.configure(bg="#2c3e50")
        dialog.grab_set()

        tk.Label(dialog, text="Pengaturan Toko", font=("Arial", 16, "bold"), 
                fg="white", bg="#2c3e50").pack(pady=20)

        # Get current store data
        try:
            self.main_app.cursor.execute('''
                SELECT store_name, jam_buka, jam_tutup FROM sellers WHERE id = %s
            ''', (self.current_seller_id,))
            store_data = self.main_app.cursor.fetchone()
            
            if not store_data:
                messagebox.showerror("Error", "Data toko tidak ditemukan")
                dialog.destroy()
                return

        except Error as e:
            messagebox.showerror("Database Error", f"Gagal memuat data toko: {e}")
            dialog.destroy()
            return

        # Form fields
        tk.Label(dialog, text="Nama Toko:", fg="white", bg="#2c3e50").pack(anchor="w", padx=20, pady=(10,0))
        store_name_entry = tk.Entry(dialog, width=40)
        store_name_entry.pack(padx=20, pady=5)
        store_name_entry.insert(0, store_data[0])

        tk.Label(dialog, text="Jam Buka:", fg="white", bg="#2c3e50").pack(anchor="w", padx=20, pady=(10,0))
        jam_buka_entry = tk.Entry(dialog, width=40)
        jam_buka_entry.pack(padx=20, pady=5)
        jam_buka_entry.insert(0, str(store_data[1]) if store_data[1] else "08:00")

        tk.Label(dialog, text="Jam Tutup:", fg="white", bg="#2c3e50").pack(anchor="w", padx=20, pady=(10,0))
        jam_tutup_entry = tk.Entry(dialog, width=40)
        jam_tutup_entry.pack(padx=20, pady=5)
        jam_tutup_entry.insert(0, str(store_data[2]) if store_data[2] else "17:00")

        def save_settings():
            try:
                new_store_name = store_name_entry.get().strip()
                new_jam_buka = jam_buka_entry.get().strip()
                new_jam_tutup = jam_tutup_entry.get().strip()

                if not new_store_name:
                    raise ValueError("Nama toko harus diisi")

                # Validate time format
                try:
                    datetime.strptime(new_jam_buka, "%H:%M")
                    datetime.strptime(new_jam_tutup, "%H:%M")
                except ValueError:
                    raise ValueError("Format jam harus HH:MM (contoh: 08:30)")

                self.main_app.cursor.execute('''
                    UPDATE sellers SET store_name=%s, jam_buka=%s, jam_tutup=%s
                    WHERE id=%s
                ''', (new_store_name, new_jam_buka, new_jam_tutup, self.current_seller_id))
                
                self.main_app.conn.commit()
                messagebox.showinfo("Sukses", "Pengaturan toko berhasil disimpan!")
                
                # Update current user data
                updated_user = list(self.current_user)
                updated_user[2] = new_store_name  # store_name
                self.current_user = tuple(updated_user)
                
                dialog.destroy()
                self.show_seller_dashboard(self.current_user)

            except ValueError as e:
                messagebox.showerror("Error", str(e))
            except Error as e:
                messagebox.showerror("Database Error", f"Gagal menyimpan pengaturan: {e}")

        tk.Button(dialog, text="💾 Simpan", command=save_settings, 
                 bg="#27ae60", fg="white", font=("Arial", 12)).pack(pady=30)

    def show_buyer_mode(self):
        """Switch to buyer mode to see all available stores"""
        self.show_buyer_mode_all_sellers()

    def show_buyer_mode_all_sellers(self):
        """Show all sellers for buyer to choose from"""
        self.main_app.clear_window()
        
        main_frame = tk.Frame(self.main_app.root, bg="#2c3e50")
        main_frame.pack(fill="both", expand=True, padx=20, pady=20)
        
        tk.Label(main_frame, text="Mode Pembeli - Pilih Kantin", 
                font=("Arial", 18, "bold"), fg="white", bg="#2c3e50").pack(pady=20)
        
        # Get buyer name
        buyer_name = simpledialog.askstring("Nama Pembeli", "Masukkan nama Anda:")
        if not buyer_name:
            if hasattr(self, 'current_user') and self.current_user:
                self.show_seller_dashboard(self.current_user)
            else:
                self.main_app.show_login_form()
            return
        
        self.current_buyer_name = buyer_name.strip()

        # Inisialisasi struktur data pembeli
        self.data = {
            "toko": {},
            "menu": {},
            "cart": {},
            "pesanan": [],
            "pesanan_terbaca": {}
        }
        
        # Store selection frame
        stores_frame = tk.Frame(main_frame, bg="#34495e")
        stores_frame.pack(fill="both", expand=True, pady=10)
        
        # Load available stores
        self.load_available_stores(stores_frame)
        
        # Back button
        back_btn = tk.Button(main_frame, text="← Kembali", font=("Arial", 12), 
                            bg="#95a5a6", fg="white")
        if hasattr(self, 'current_user') and self.current_user:
            back_btn.config(command=lambda: self.show_seller_dashboard(self.current_user))
        else:
            back_btn.config(command=self.main_app.show_login_form)
        back_btn.pack(pady=10)

    def load_available_stores(self, parent):
        """Load stores that are currently open"""
        try:
            current_time = datetime.now().time()
            
            self.main_app.cursor.execute('''
                SELECT id, seller_name, store_name, image_path, jam_buka, jam_tutup
                FROM sellers 
                WHERE jam_buka <= %s AND jam_tutup >= %s
                ORDER BY store_name
            ''', (current_time, current_time))
            
            open_stores = self.main_app.cursor.fetchall()
            
            if not open_stores:
                tk.Label(parent, text="Belum ada kantin yang buka saat ini", 
                        font=("Arial", 14), fg="white", bg="#34495e").pack(pady=20)
                return
            
            for store in open_stores:
                # Simpan data toko ke self.data
                self.data["toko"][store[0]] = {
                    "nama_toko": store[2],
                    "jam_buka": str(store[4]),
                    "jam_tutup": str(store[5])
                }

                # Ambil semua menu dari toko ini
                try:
                    self.main_app.cursor.execute('''
                        SELECT id, nama, harga, stok, diskon
                        FROM menu_items WHERE seller_id = %s
                    ''', (store[0],))
                    menu_list = self.main_app.cursor.fetchall()
                    for menu in menu_list:
                        self.data["menu"][menu[0]] = {
                            "nama": menu[1],
                            "harga": menu[2],
                            "stok": menu[3],
                            "diskon": menu[4],
                            "toko_id": store[0]
                        }
                except Error as e:
                    messagebox.showerror("Database Error", f"Gagal memuat menu dari toko {store[2]}: {e}")

                self.create_store_selection_widget(parent, store)  # Panggil dengan parameter yang benar
                
        except Error as e:
            messagebox.showerror("Database Error", f"Gagal memuat daftar kantin: {e}")

    def create_store_selection_widget(self, parent, store):
        """Create widget for store selection"""
        store_frame = tk.Frame(parent, bg="#ecf0f1", relief="raised", bd=2)
        store_frame.pack(fill="x", pady=10, padx=10)
        
        # Store info
        info_frame = tk.Frame(store_frame, bg="#ecf0f1")
        info_frame.pack(side="left", fill="x", expand=True, padx=15, pady=10)

        # store adalah tuple: (id, seller_name, store_name, image_path, jam_buka, jam_tutup)
        tk.Label(info_frame, text=store[2],  # store_name
                font=("Arial", 16, "bold"), bg="#ecf0f1").pack(anchor="w")
        tk.Label(info_frame, text=f"Pemilik: {store[1]}",  # seller_name
                font=("Arial", 10), bg="#ecf0f1", fg="gray").pack(anchor="w")
        tk.Label(info_frame, text=f"Jam Buka: {store[4]} - {store[5]}",  # jam_buka - jam_tutup
                font=("Arial", 10), bg="#ecf0f1", fg="gray").pack(anchor="w")

        # Action button
        btn_frame = tk.Frame(store_frame, bg="#ecf0f1")
        btn_frame.pack(side="right", padx=15, pady=10)

        tk.Button(btn_frame, text="Lihat Menu", font=("Arial", 12),
                bg="#3498db", fg="white", width=12,
                command=lambda: self.show_buyer_menu(store[0])).pack()
        
    def show_buyer_menu(self, toko_id):
        """Show menu for buyers with enhanced UI"""
        self.current_toko = toko_id
        self.clear_screen()
        
        main_frame = tk.Frame(self.root, bg="#2c3e50")
        main_frame.pack(fill="both", expand=True, padx=20, pady=20)
        
        # Header
        header = tk.Frame(main_frame, bg="#34495e")
        header.pack(fill="x", pady=10)
        
        tk.Label(header, text=f"Menu - {self.data['toko'][toko_id]['nama_toko']}", 
                font=("Arial", 16, "bold"), fg="white", bg="#34495e").pack(side="left", padx=10, pady=10)
        
        self.total_label = tk.Label(header, text="Total: Rp 0", 
                                font=("Arial", 14, "bold"), fg="#27ae60", bg="#34495e")
        self.total_label.pack(side="right", padx=10, pady=10)
        
        # Menu container with scrollbar
        canvas = tk.Canvas(main_frame, bg="#2c3e50")
        scrollbar = ttk.Scrollbar(main_frame, orient="vertical", command=canvas.yview)
        scrollable_frame = tk.Frame(canvas, bg="#2c3e50")
        
        canvas.configure(yscrollcommand=scrollbar.set)
        canvas.create_window((0, 0), window=scrollable_frame, anchor="nw")
        
        # Get menu untuk toko ini (sorted by discount)
        menu_list = []
        for menu_id, menu in self.data['menu'].items():
            if menu['toko_id'] == toko_id and menu['stok'] > 0:
                menu_list.append((menu_id, menu))
        
        menu_list.sort(key=lambda x: x[1].get('diskon', 0), reverse=True)
        
        for menu_id, menu in menu_list:
            self.create_enhanced_menu_item(scrollable_frame, menu_id, menu)
        
        scrollable_frame.update_idletasks()
        canvas.configure(scrollregion=canvas.bbox("all"))
        
        canvas.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")
        
        # Bottom buttons
        btn_frame = tk.Frame(main_frame, bg="#2c3e50")
        btn_frame.pack(fill="x", pady=10)
        
        tk.Button(btn_frame, text="🛒 Pesan Sekarang", font=("Arial", 12), 
                bg="#27ae60", fg="white", width=15,
                command=self.konfirmasi_pesanan_enhanced).pack(side="right", padx=5)
        tk.Button(btn_frame, text="← Kembali", font=("Arial", 12), 
                bg="#95a5a6", fg="white", width=12,
                command=self.show_buyer_mode_all_sellers).pack(side="left", padx=5)

    def create_enhanced_menu_item(self, parent, menu_id, menu):
        """Create enhanced menu item widget"""
        item_frame = tk.Frame(parent, bg="#ecf0f1", relief="raised", bd=2)
        item_frame.pack(fill="x", pady=8, padx=10)
        
        # Menu info section
        info_frame = tk.Frame(item_frame, bg="#ecf0f1")
        info_frame.pack(side="left", fill="x", expand=True, padx=15, pady=10)
        
        # Menu name with discount badge
        name_frame = tk.Frame(info_frame, bg="#ecf0f1")
        name_frame.pack(anchor="w", fill="x")
        
        tk.Label(name_frame, text=menu['nama'], font=("Arial", 14, "bold"), 
                bg="#ecf0f1").pack(side="left")
        
        if menu.get('diskon', 0) > 0:
            discount_label = tk.Label(name_frame, text=f"{menu['diskon']}% OFF", 
                                    font=("Arial", 10, "bold"), bg="#e74c3c", fg="white")
            discount_label.pack(side="left", padx=10)
        
        # Price section
        price_frame = tk.Frame(info_frame, bg="#ecf0f1")
        price_frame.pack(anchor="w", pady=2)
        
        harga_asli = menu['harga']
        harga_diskon = harga_asli * (100 - menu.get('diskon', 0)) / 100
        
        if menu.get('diskon', 0) > 0:
            tk.Label(price_frame, text=f"Rp {int(harga_asli):,}", 
                    font=("Arial", 11), bg="#ecf0f1", fg="gray").pack(side="left")
            tk.Label(price_frame, text="→", font=("Arial", 11), 
                    bg="#ecf0f1", fg="gray").pack(side="left", padx=5)
            tk.Label(price_frame, text=f"Rp {int(harga_diskon):,}", 
                    font=("Arial", 12, "bold"), bg="#ecf0f1", fg="#e74c3c").pack(side="left")
        else:
            tk.Label(price_frame, text=f"Rp {int(harga_asli):,}", 
                    font=("Arial", 12, "bold"), bg="#ecf0f1").pack(side="left")
        
        tk.Label(info_frame, text=f"Stok tersisa: {menu['stok']}", 
                font=("Arial", 10), bg="#ecf0f1", fg="gray").pack(anchor="w")
        
        # Quantity controls
        qty_frame = tk.Frame(item_frame, bg="#ecf0f1")
        qty_frame.pack(side="right", padx=15, pady=10)
        
        qty_var = tk.StringVar(value=str(self.data['cart'].get(menu_id, 0)))
        
        if menu['stok'] == 0:
            tk.Label(qty_frame, text="❌ HABIS", fg="red", 
                    font=("Arial", 12, "bold"), bg="#ecf0f1").pack()
        else:
            control_frame = tk.Frame(qty_frame, bg="#ecf0f1")
            control_frame.pack()
            
            tk.Button(control_frame, text="−", width=3, font=("Arial", 12, "bold"),
                    bg="#e74c3c", fg="white",
                    command=lambda: self.update_cart_enhanced(menu_id, -1, qty_var)).pack(side="left")
            
            qty_label = tk.Label(control_frame, textvariable=qty_var, width=4, 
                            font=("Arial", 12, "bold"), bg="white", relief="sunken")
            qty_label.pack(side="left", padx=5)
            
            tk.Button(control_frame, text="+", width=3, font=("Arial", 12, "bold"),
                    bg="#27ae60", fg="white",
                    command=lambda: self.update_cart_enhanced(menu_id, 1, qty_var)).pack(side="left")

    def update_cart_enhanced(self, menu_id, change, qty_var):
        """Enhanced cart update with animations and validation"""
        current_qty = self.data['cart'].get(menu_id, 0)
        new_qty = max(0, current_qty + change)
        
        # Check stok
        if new_qty > self.data['menu'][menu_id]['stok']:
            messagebox.showwarning("Stok Habis", 
                                f"Stok {self.data['menu'][menu_id]['nama']} tidak mencukupi!\n"
                                f"Stok tersisa: {self.data['menu'][menu_id]['stok']}")
            return
        
        if new_qty == 0:
            self.data['cart'].pop(menu_id, None)
        else:
            self.data['cart'][menu_id] = new_qty
        
        qty_var.set(str(new_qty))
        self.update_total_enhanced()

    def update_total_enhanced(self):
        """Enhanced total calculation with better formatting"""
        total = 0
        item_count = 0
        
        for menu_id, qty in self.data['cart'].items():
            menu = self.data['menu'][menu_id]
            harga = menu['harga'] * (100 - menu.get('diskon', 0)) / 100
            total += harga * qty
            item_count += qty
        
        if item_count > 0:
            self.total_label.config(text=f"Total: Rp {int(total):,} ({item_count} item)")
        else:
            self.total_label.config(text="Total: Rp 0")

    def konfirmasi_pesanan_enhanced(self):
        """Enhanced order confirmation with better UI"""
        if not self.data['cart']:
            messagebox.showwarning("Keranjang Kosong", "Silakan pilih menu terlebih dahulu!")
            return
        
        self.clear_screen()
        
        main_frame = tk.Frame(self.root, bg="#2c3e50")
        main_frame.pack(fill="both", expand=True, padx=20, pady=20)
        
        tk.Label(main_frame, text="📋 Konfirmasi Pesanan", 
                font=("Arial", 18, "bold"), fg="white", bg="#2c3e50").pack(pady=15)
        
        # Order summary frame
        summary_frame = tk.Frame(main_frame, bg="#34495e", relief="raised", bd=2)
        summary_frame.pack(fill="x", pady=10, padx=10)
        
        tk.Label(summary_frame, text="Ringkasan Pesanan", 
                font=("Arial", 14, "bold"), fg="white", bg="#34495e").pack(pady=10)
        
        total = 0
        for menu_id, qty in self.data['cart'].items():
            menu = self.data['menu'][menu_id]
            harga = menu['harga'] * (100 - menu.get('diskon', 0)) / 100
            subtotal = harga * qty
            total += subtotal
            
            item_frame = tk.Frame(summary_frame, bg="#34495e")
            item_frame.pack(fill="x", padx=15, pady=2)
            
            tk.Label(item_frame, text=f"{menu['nama']} x{qty}", 
                    font=("Arial", 11), fg="white", bg="#34495e").pack(side="left")
            tk.Label(item_frame, text=f"Rp {int(subtotal):,}", 
                    font=("Arial", 11), fg="#27ae60", bg="#34495e").pack(side="right")
        
        # Total
        total_frame = tk.Frame(summary_frame, bg="#27ae60")
        total_frame.pack(fill="x", padx=10, pady=10)
        
        tk.Label(total_frame, text=f"TOTAL: Rp {int(total):,}", 
                font=("Arial", 14, "bold"), fg="white", bg="#27ae60").pack(pady=5)
        
        # Form section
        form_frame = tk.Frame(main_frame, bg="#ecf0f1")
        form_frame.pack(fill="both", expand=True, pady=10, padx=10)
        
        # Customer info
        tk.Label(form_frame, text="Informasi Pemesan", font=("Arial", 12, "bold")).pack(anchor="w", padx=10, pady=(10,5))
        tk.Label(form_frame, text=f"Nama: {self.current_buyer_name}", font=("Arial", 11)).pack(anchor="w", padx=10)
        
        # Notes
        tk.Label(form_frame, text="Catatan tambahan:", font=("Arial", 11)).pack(anchor="w", padx=10, pady=(15,5))
        self.catatan_text = tk.Text(form_frame, height=4, width=60, font=("Arial", 10))
        self.catatan_text.pack(padx=10, pady=5)
        
        # Pickup time
        tk.Label(form_frame, text="Waktu Pengambilan:", font=("Arial", 11)).pack(anchor="w", padx=10, pady=(15,5))
        
        time_frame = tk.Frame(form_frame)
        time_frame.pack(anchor="w", padx=10, pady=5)
        
        tomorrow = datetime.now() + timedelta(days=1)
        self.date_var = tk.StringVar(value=tomorrow.strftime("%Y-%m-%d"))
        self.time_var = tk.StringVar(value="12:00")
        
        tk.Label(time_frame, text="Tanggal:").pack(side="left")
        tk.Entry(time_frame, textvariable=self.date_var, width=12, font=("Arial", 10)).pack(side="left", padx=5)
        tk.Label(time_frame, text="Jam:").pack(side="left", padx=(10,0))
        tk.Entry(time_frame, textvariable=self.time_var, width=8, font=("Arial", 10)).pack(side="left", padx=5)
        
        # Buttons
        btn_frame = tk.Frame(main_frame, bg="#2c3e50")
        btn_frame.pack(fill="x", pady=15)
        
        tk.Button(btn_frame, text="💳 Bayar & Pesan", font=("Arial", 14, "bold"), 
                bg="#27ae60", fg="white", width=18, height=2,
                command=self.proses_pembayaran_enhanced).pack(side="right", padx=10)
        tk.Button(btn_frame, text="← Kembali", font=("Arial", 12), 
                bg="#95a5a6", fg="white", width=12,
                command=lambda: self.show_buyer_menu(self.current_toko)).pack(side="left", padx=10)

    def proses_pembayaran_enhanced(self):
        """Enhanced payment processing with better validation"""
        # Validate date
        try:
            order_date = datetime.strptime(self.date_var.get(), "%Y-%m-%d")
            if order_date.date() <= datetime.now().date():
                messagebox.showerror("Tanggal Tidak Valid", 
                                "Pesanan hanya bisa dibuat untuk hari besok atau setelahnya!")
                return
        except ValueError:
            messagebox.showerror("Format Tanggal Salah", 
                            "Gunakan format YYYY-MM-DD (contoh: 2024-12-25)")
            return
        
        # Validate time
        # Validasi waktu (tanpa try-except besar yang menutup semua error)
        time_input = self.time_var.get().strip()
        if not time_input:
            messagebox.showerror("Format Jam Salah", "Jam pengambilan tidak boleh kosong.")
            return

        try:
            order_time = datetime.strptime(time_input, "%H:%M")
        except ValueError:
            messagebox.showerror("Format Jam Salah", "Gunakan format HH:MM (contoh: 14:30)")
            return

        # Ambil jam buka-tutup dari data toko
        try:
            toko = self.data['toko'][self.current_toko]
            jam_buka = datetime.strptime(toko['jam_buka'], "%H:%M:%S").time()
            jam_tutup = datetime.strptime(toko['jam_tutup'], "%H:%M:%S").time()
        except Exception as e:
            messagebox.showerror("Data Error", f"Gagal membaca jam buka/tutup: {e}")
            return

        # Validasi apakah waktu pengambilan dalam rentang buka
        if not (jam_buka <= order_time.time() <= jam_tutup):
            messagebox.showerror("Jam Tidak Valid", 
                            f"Pilih jam antara {toko['jam_buka']} - {toko['jam_tutup']}")
            return
        
        # Calculate total for confirmation
        total = 0
        for menu_id, qty in self.data['cart'].items():
            menu = self.data['menu'][menu_id]
            harga = menu['harga'] * (100 - menu.get('diskon', 0)) / 100
            total += harga * qty
        
        # Final confirmation
        if not messagebox.askyesno("Konfirmasi Pembayaran", 
                                f"Total pembayaran: Rp {int(total):,}\n"
                                f"Tanggal ambil: {self.date_var.get()}\n"
                                f"Jam ambil: {self.time_var.get()}\n\n"
                                "Lanjutkan pembayaran?"):
            return
        
        # Save order
        pesanan = {
            'id': len(self.data['pesanan']) + 1,
            'pembeli': self.current_buyer_name,
            'toko_id': self.current_toko,
            'menu': dict(self.data['cart']),
            'catatan': self.catatan_text.get(1.0, tk.END).strip(),
            'tanggal_ambil': self.date_var.get(),
            'jam_ambil': self.time_var.get(),
            'timestamp': datetime.now().isoformat(),
            'total': int(total),
            'status': 'confirmed'
        }
        
        # Update stock
        for menu_id, qty in self.data['cart'].items():
            self.data['menu'][menu_id]['stok'] -= qty
        
        # Mark new order for store
        self.data['pesanan_terbaca'][self.current_toko] = False
        
        # Show success message
        self.tampil_sukses_pesanan(pesanan)

    def tampil_sukses_pesanan(self, pesanan):
        """Display order success screen"""
        self.clear_screen()
        
        main_frame = tk.Frame(self.root, bg="#27ae60")
        main_frame.pack(fill="both", expand=True)
        
        content_frame = tk.Frame(main_frame, bg="white")
        content_frame.pack(expand=True, padx=50, pady=50)
        
        # Success icon and message
        tk.Label(content_frame, text="✅", font=("Arial", 48), bg="white").pack(pady=20)
        tk.Label(content_frame, text="Pesanan Berhasil!", 
                font=("Arial", 24, "bold"), bg="white", fg="#27ae60").pack(pady=10)
        
        # Order details
        details_frame = tk.Frame(content_frame, bg="#f8f9fa", relief="groove", bd=2)
        details_frame.pack(fill="x", pady=20, padx=20)
        
        tk.Label(details_frame, text="Detail Pesanan", 
                font=("Arial", 14, "bold"), bg="#f8f9fa").pack(pady=10)
        
        tk.Label(details_frame, text=f"Nomor Pesanan: #{pesanan['id']}", 
                font=("Arial", 12), bg="#f8f9fa").pack()
        tk.Label(details_frame, text=f"Total: Rp {pesanan['total']:,}", 
                font=("Arial", 12, "bold"), bg="#f8f9fa", fg="#27ae60").pack()
        tk.Label(details_frame, text=f"Tanggal Ambil: {pesanan['tanggal_ambil']}", 
                font=("Arial", 12), bg="#f8f9fa").pack()
        tk.Label(details_frame, text=f"Jam Ambil: {pesanan['jam_ambil']}", 
                font=("Arial", 12), bg="#f8f9fa").pack(pady=(0,10))
        
        # Reminder
        tk.Label(content_frame, text="Jangan lupa datang tepat waktu untuk mengambil pesanan Anda!", 
                font=("Arial", 11), bg="white", fg="gray").pack(pady=10)
        
        # Buttons
        btn_frame = tk.Frame(content_frame, bg="white")
        btn_frame.pack(pady=20)
        
        tk.Button(btn_frame, text="🏠 Kembali ke Beranda", font=("Arial", 12), 
                bg="#3498db", fg="white", width=20,
                command=self.show_buyer_mode_all_sellers).pack(side="left", padx=10)
        tk.Button(btn_frame, text="📱 Pesan Lagi", font=("Arial", 12), 
                bg="#27ae60", fg="white", width=20,
                command=lambda: self.show_buyer_menu(self.current_toko)).pack(side="left", padx=10)
        
        # Clear cart
        self.data['cart'] = {}