import tkinter as tk
from tkinter import ttk, messagebox
from PIL import Image, ImageTk
import os

class ShopeeClone:
    def __init__(self, root):
        self.root = root
        self.root.title("E-Commerce Recommendation System")
        self.root.geometry("1000x700")
        self.root.configure(bg="#ffffff")
        
        # Data
        self.products = self.load_products()
        self.cart = []
        self.budget = 0
        
        # Main frames
        self.create_header()
        self.create_main_content()
        self.create_footer()
        
    def load_products(self):
        # Simulated product database
        products = [
            {"id": 1, "name": "Smartphone X", "category": "Elektronik", "price": 2500000, "stock": 15, 
             "eco_friendly": False, "image": "smartphone.jpg", "description": "Smartphone canggih dengan kamera 48MP"},
            {"id": 2, "name": "Laptop Pro", "category": "Elektronik", "price": 8000000, "stock": 8, 
             "eco_friendly": False, "image": "laptop.png", "description": "Laptop dengan prosesor terbaru"},
            {"id": 3, "name": "Headphone Wireless", "category": "Aksesori Elektronik", "price": 800000, "stock": 25, 
             "eco_friendly": False, "image": "headphone.png", "description": "Headphone nirkabel dengan noise cancelling"},
            {"id": 4, "name": "Powerbank 10000mAh", "category": "Aksesori Elektronik", "price": 350000, "stock": 30, 
             "eco_friendly": False, "image": "powerbank.png", "description": "Powerbank berkualitas dengan fast charging"},
            {"id": 5, "name": "T-Shirt Katun Organik", "category": "Pakaian", "price": 150000, "stock": 40, 
             "eco_friendly": True, "image": "tshirt.png", "description": "T-shirt dari katun organik ramah lingkungan"},
            {"id": 6, "name": "Celana Jeans", "category": "Pakaian", "price": 300000, "stock": 35, 
             "eco_friendly": False, "image": "jeans1.png", "description": "Celana jeans dengan bahan premium"},
            {"id": 7, "name": "Totebag Kanvas", "category": "Aksesori Fashion", "price": 80000, "stock": 50, 
             "eco_friendly": True, "image": "totebag.png", "description": "Totebag dari kanvas daur ulang"},
            {"id": 8, "name": "Botol Minum Tumbler", "category": "Peralatan Rumah", "price": 120000, "stock": 45, 
             "eco_friendly": True, "image": "bottle.png", "description": "Botol minum ramah lingkungan, bebas BPA"},
            {"id": 9, "name": "Charger Type-C", "category": "Aksesori Elektronik", "price": 150000, "stock": 60, 
             "eco_friendly": False, "image": "charger.png", "description": "Charger cepat untuk perangkat Type-C"},
            {"id": 10, "name": "Case Smartphone", "category": "Aksesori Elektronik", "price": 75000, "stock": 100, 
             "eco_friendly": False, "image": "case.png", "description": "Pelindung smartphone anti benturan"},
        ]
        return products
    
    def create_header(self):
        # Header Frame
        header_frame = tk.Frame(self.root, bg="#fb5533", height=60)
        header_frame.pack(fill="x")
        
        # Logo
        logo_label = tk.Label(header_frame, text="ShopeeClone", font=("Arial", 18, "bold"), bg="#fb5533", fg="white")
        logo_label.pack(side="left", padx=20, pady=10)
        
        # Search Bar
        search_frame = tk.Frame(header_frame, bg="#fb5533")
        search_frame.pack(side="left", fill="x", expand=True, padx=20, pady=10)
        
        self.search_entry = tk.Entry(search_frame, font=("Arial", 12), width=40)
        self.search_entry.pack(side="left", fill="x", expand=True)
        
        search_button = tk.Button(search_frame, text="Cari", bg="#f85032", fg="white", 
                                 font=("Arial", 10, "bold"), command=self.search_products)
        search_button.pack(side="left", padx=5)
        
        # Budget Display
        self.budget_display = tk.Label(header_frame, text=f"Saldo: Rp {self.budget:,}", 
                                      font=("Arial", 10, "bold"), bg="#fb5533", fg="white")
        self.budget_display.pack(side="right", padx=10, pady=10)
        
        # Cart Button
        self.cart_button = tk.Button(header_frame, text="Keranjang (0)", bg="#f85032", fg="white", 
                                    font=("Arial", 10, "bold"), command=self.show_cart)
        self.cart_button.pack(side="right", padx=10, pady=10)
        
    def create_main_content(self):
        # Main Content Frame
        main_frame = tk.Frame(self.root, bg="#f2f2f2")
        main_frame.pack(fill="both", expand=True, padx=20, pady=10)
        
        # Left Sidebar - Categories & Preferences
        sidebar_frame = tk.Frame(main_frame, bg="white", width=200)
        sidebar_frame.pack(side="left", fill="y", padx=(0, 10))
        sidebar_frame.pack_propagate(False)
        
        # Budget Setting
        budget_frame = tk.Frame(sidebar_frame, bg="white")
        budget_frame.pack(fill="x", pady=10, padx=10)
        
        tk.Label(budget_frame, text="Anggaran (Rp):", bg="white").pack(anchor="w")
        self.budget_entry = tk.Entry(budget_frame)
        self.budget_entry.pack(fill="x", pady=5)
        self.budget_entry.insert(0, "0")
        
        budget_button = tk.Button(budget_frame, text="Atur Anggaran", 
                                 command=self.set_budget, bg="#fb5533", fg="white")
        budget_button.pack(fill="x")
        
        # Current Budget Display in Sidebar
        self.sidebar_budget_display = tk.Label(sidebar_frame, text=f"Saldo Anda: Rp {self.budget:,}", 
                                             bg="white", font=("Arial", 10, "bold"))
        self.sidebar_budget_display.pack(fill="x", pady=5, padx=10)
        
        # Categories
        category_frame = tk.Frame(sidebar_frame, bg="white")
        category_frame.pack(fill="x", pady=10, padx=10)
        
        tk.Label(category_frame, text="Kategori Produk:", bg="white", font=("Arial", 10, "bold")).pack(anchor="w")
        
        categories = ["Semua", "Elektronik", "Aksesori Elektronik", "Pakaian", "Aksesori Fashion", "Peralatan Rumah"]
        self.category_var = tk.StringVar(value="Semua")
        
        for category in categories:
            rb = tk.Radiobutton(category_frame, text=category, variable=self.category_var, 
                               value=category, bg="white", command=self.filter_products)
            rb.pack(anchor="w", pady=2)
        
        # Preferences
        pref_frame = tk.Frame(sidebar_frame, bg="white")
        pref_frame.pack(fill="x", pady=10, padx=10)
        
        tk.Label(pref_frame, text="Preferensi Pribadi:", bg="white", font=("Arial", 10, "bold")).pack(anchor="w")
        
        self.eco_var = tk.BooleanVar(value=False)
        eco_check = tk.Checkbutton(pref_frame, text="Produk Ramah Lingkungan", variable=self.eco_var, 
                                  bg="white", command=self.filter_products)
        eco_check.pack(anchor="w", pady=2)
        
        # Products Display Area
        self.products_frame = tk.Frame(main_frame, bg="#f2f2f2")
        self.products_frame.pack(side="left", fill="both", expand=True)
        
        # Initial display of products
        self.display_products()
        
    def create_footer(self):
        # Footer Frame
        footer_frame = tk.Frame(self.root, bg="#fb5533", height=30)
        footer_frame.pack(fill="x", side="bottom")
        
        # Footer Text
        footer_text = tk.Label(footer_frame, text="© 2025 UTS ALPRO 2 - Kelompok 7", 
                              bg="#fb5533", fg="white", font=("Arial", 10))
        footer_text.pack(pady=5)
    
    def display_products(self, products_to_display=None):
        # Clear previous products
        for widget in self.products_frame.winfo_children():
            widget.destroy()
            
        if products_to_display is None:
            products_to_display = self.products
            
        # Create a canvas with scrollbar
        canvas = tk.Canvas(self.products_frame, bg="#f2f2f2")
        scrollbar = ttk.Scrollbar(self.products_frame, orient="vertical", command=canvas.yview)
        
        canvas.configure(yscrollcommand=scrollbar.set)
        scrollbar.pack(side="right", fill="y")
        canvas.pack(side="left", fill="both", expand=True)
        
        # Frame inside canvas for products
        inner_frame = tk.Frame(canvas, bg="#f2f2f2")
        canvas.create_window((0, 0), window=inner_frame, anchor="nw")
        
        # Display products in a grid
        row, col = 0, 0
        for product in products_to_display:
            product_card = self.create_product_card(inner_frame, product)
            product_card.grid(row=row, column=col, padx=10, pady=10, sticky="nsew")
            
            col += 1
            if col > 2:  # 3 products per row
                col = 0
                row += 1
                
        # Update canvas scroll region
        inner_frame.update_idletasks()
        canvas.config(scrollregion=canvas.bbox("all"))
        
        # Configure grid weights
        for i in range(3):
            inner_frame.columnconfigure(i, weight=1)
    
    def create_product_card(self, parent, product):
        # Product Card Frame
        card = tk.Frame(parent, bg="white", width=200, height=320, relief="raised", bd=1)
        card.pack_propagate(False)

        # Placeholder untuk gambar produk
        img_placeholder = tk.Frame(card, bg="#e0e0e0", width=180, height=150)
        img_placeholder.pack(pady=(10, 5), padx=10)

        try:
            # Ubah base path ke folder 'foto'
            base_path = r"C:\TUGAS INFOR\SEMESTER 2\ALPRO 2\foto"
            img_path = os.path.join(base_path, product["image"])  # Gabungkan path

            if not os.path.exists(img_path):
                raise FileNotFoundError(f"Gambar tidak ditemukan: {img_path}")

            # Load gambar
            img = Image.open(img_path)
        
            # Maintain aspect ratio by calculating new dimensions
            img_width, img_height = img.size
            max_size = 150
            
            # Calculate scaling factor to maintain aspect ratio
            scale_factor = min(max_size / img_width, max_size / img_height)
            new_width = int(img_width * scale_factor)
            new_height = int(img_height * scale_factor)
        
            img = img.resize((new_width, new_height))
            img = ImageTk.PhotoImage(img)

            img_label = tk.Label(img_placeholder, image=img, bg="#e0e0e0")
            img_label.image = img  # Simpan referensi biar nggak hilang
            img_label.pack(expand=True)

        except Exception as e:
            print(f"Error loading image {img_path}: {e}")
            img_label = tk.Label(img_placeholder, text="Gambar tidak ditemukan", bg="#e0e0e0")
            img_label.pack(expand=True, fill="both")

        # Product info
        name_label = tk.Label(card, text=product["name"], font=("Arial", 10, "bold"), bg="white")
        name_label.pack(pady=(5, 0), padx=10, anchor="w")

        price_label = tk.Label(card, text=f"Rp {product['price']:,}", font=("Arial", 10), bg="white", fg="#fb5533")
        price_label.pack(pady=(2, 0), padx=10, anchor="w")

        stock_label = tk.Label(card, text=f"Stok: {product['stock']}", font=("Arial", 8), bg="white")
        stock_label.pack(pady=(2, 0), padx=10, anchor="w")

        category_label = tk.Label(card, text=f"Kategori: {product['category']}", font=("Arial", 8), bg="white")
        category_label.pack(pady=(2, 0), padx=10, anchor="w")

        if product["eco_friendly"]:
            eco_label = tk.Label(card, text="Ramah Lingkungan", font=("Arial", 8), bg="#4CAF50", fg="white")
            eco_label.pack(pady=(2, 0), padx=10, anchor="w")

        spacer = tk.Frame(card, bg="white")
        spacer.pack(expand=True, fill="both")

        # Add to cart button
        add_button = tk.Button(card, text="Tambah ke Keranjang", bg="#fb5533", fg="white",
                          command=lambda p=product: self.add_to_cart(p))
        add_button.pack(pady=(0, 5), padx=10, fill="x", side="bottom")

        return card

    
    def add_to_cart(self, product):
        # Check if item is in stock
        if product["stock"] <= 0:
            messagebox.showerror("Stok Habis", "Maaf, produk ini sedang tidak tersedia.")
            return
    
        # Update stok produk
        for p in self.products:
            if p["id"] == product["id"]:
                p["stock"] -= 1
                break
    
        # Add to cart
        self.cart.append(product)
    
        # Update cart button
        self.cart_button.config(text=f"Keranjang ({len(self.cart)})")
    
        # Show feedback
        messagebox.showinfo("Berhasil", f"{product['name']} telah ditambahkan ke keranjang.")
    
        # Update products display to reflect stock changes
        self.display_products()
    
        # Generate recommendations based on current cart
        self.show_recommendations()

    
    def show_cart(self):
        if not self.cart:
            messagebox.showinfo("Keranjang Kosong", "Keranjang belanja Anda kosong.")
            return
            
        # Create a new window for cart
        cart_window = tk.Toplevel(self.root)
        cart_window.title("Keranjang Belanja")
        cart_window.geometry("600x500")
        cart_window.configure(bg="white")
        
        # Cart items frame
        items_frame = tk.Frame(cart_window, bg="white")
        items_frame.pack(fill="both", expand=True, padx=20, pady=20)
        
        # Headings
        tk.Label(items_frame, text="Produk", font=("Arial", 10, "bold"), bg="white", width=20).grid(row=0, column=0, sticky="w")
        tk.Label(items_frame, text="Kategori", font=("Arial", 10, "bold"), bg="white", width=15).grid(row=0, column=1, sticky="w")
        tk.Label(items_frame, text="Harga", font=("Arial", 10, "bold"), bg="white", width=12).grid(row=0, column=2, sticky="w")
        tk.Label(items_frame, text="", width=10, bg="white").grid(row=0, column=3, sticky="w")
        
        tk.Frame(items_frame, height=2, bg="#e0e0e0").grid(row=1, column=0, columnspan=4, sticky="ew", pady=5)
        
        # Display cart items
        total_price = 0
        for i, item in enumerate(self.cart):
            tk.Label(items_frame, text=item["name"], bg="white").grid(row=i+2, column=0, sticky="w", pady=5)
            tk.Label(items_frame, text=item["category"], bg="white").grid(row=i+2, column=1, sticky="w", pady=5)
            tk.Label(items_frame, text=f"Rp {item['price']:,}", bg="white").grid(row=i+2, column=2, sticky="w", pady=5)
            
            remove_btn = tk.Button(items_frame, text="Hapus", bg="#fb5533", fg="white",
                                  command=lambda idx=i: self.remove_from_cart(idx, cart_window))
            remove_btn.grid(row=i+2, column=3, sticky="w", pady=5)
            
            total_price += item["price"]
        
        # Summary frame
        summary_frame = tk.Frame(cart_window, bg="#f5f5f5", bd=1, relief="solid")
        summary_frame.pack(fill="x", padx=20, pady=(0, 20))
        
        # Budget info
        budget_info = f"Anggaran: Rp {self.budget:,}" if self.budget > 0 else "Anggaran: Tidak diatur"
        tk.Label(summary_frame, text=budget_info, bg="#f5f5f5", font=("Arial", 10)).pack(anchor="w", padx=10, pady=(10, 0))
        
        # Total price
        tk.Label(summary_frame, text=f"Total Harga: Rp {total_price:,}", bg="#f5f5f5", font=("Arial", 12, "bold")).pack(anchor="w", padx=10, pady=(5, 0))
        
        # Remaining balance
        remaining_balance = self.budget - total_price if self.budget > 0 else 0
        balance_color = "green" if remaining_balance >= 0 else "red"
        
        if self.budget > 0:
            tk.Label(summary_frame, text=f"Sisa Saldo: Rp {remaining_balance:,}", 
                    bg="#f5f5f5", fg=balance_color, font=("Arial", 10, "bold")).pack(anchor="w", padx=10, pady=(5, 0))
        
        # Budget warning if applicable
        if self.budget > 0 and total_price > self.budget:
            tk.Label(summary_frame, text="Peringatan: Total harga melebihi anggaran!", 
                    bg="#f5f5f5", fg="red", font=("Arial", 10)).pack(anchor="w", padx=10, pady=(5, 10))
        
        # Checkout button
        checkout_btn = tk.Button(cart_window, text="Checkout", bg="#fb5533", fg="white", font=("Arial", 12, "bold"),
                              command=lambda: self.checkout(cart_window))
        checkout_btn.pack(pady=(0, 20), ipadx=20, ipady=5)
    
    def remove_from_cart(self, index, cart_window):
        # Ambil item yang dihapus
        removed_item = self.cart[index]
    
        # Kembalikan stok produk
        for product in self.products:
            if product["id"] == removed_item["id"]:
                product["stock"] += 1
                break
    
        # Hapus dari keranjang
        self.cart.pop(index)
    
        # Update tampilan keranjang
        self.cart_button.config(text=f"Keranjang ({len(self.cart)})")
        cart_window.destroy()
    
        # Tampilkan ulang keranjang
        self.show_cart()
    
        # Update tampilan produk untuk merefleksikan perubahan stok
        self.display_products()
    
    def checkout(self, cart_window):
        total_price = sum(item["price"] for item in self.cart)
    
        if self.budget == 0:
            messagebox.showerror("Saldo Kosong", "Anda tidak bisa melakukan checkout karena saldo Anda 0.")
            return
    
        if self.budget > 0 and total_price > self.budget:
            messagebox.showerror("Saldo Tidak Cukup", "Total harga melebihi anggaran Anda.")
            return
    
    # Hapus bagian pengurangan stok karena sudah dilakukan saat add_to_cart
    # Kode pengurangan stok yang dihapus:
    # for cart_item in self.cart:
    #     for product in self.products:
    #         if product["id"] == cart_item["id"]:
    #             product["stock"] -= 1
    
    # Update budget jika diatur
        if self.budget > 0:
            self.budget -= total_price
            self.update_budget_displays()
    
    # Proses checkout
        messagebox.showinfo("Checkout Berhasil", f"Terima kasih atas pembelian Anda!\nTotal: Rp {total_price:,}\nSisa saldo: Rp {self.budget:,}")
    
    # Kosongkan keranjang dan perbarui UI
        self.cart = []
        self.cart_button.config(text="Keranjang (0)")
        cart_window.destroy()
    
    def set_budget(self):
        try:
            budget_value = int(self.budget_entry.get())
            if budget_value < 0:
                messagebox.showerror("Error", "Anggaran tidak boleh negatif.")
                return
                
            self.budget = budget_value
            self.update_budget_displays()
            messagebox.showinfo("Anggaran Diatur", f"Anggaran Anda diatur ke Rp {self.budget:,}")
        except ValueError:
            messagebox.showerror("Error", "Masukkan angka yang valid.")
    
    def update_budget_displays(self):
        # Update all budget displays in the UI
        self.budget_display.config(text=f"Saldo: Rp {self.budget:,}")
        self.sidebar_budget_display.config(text=f"Saldo Anda: Rp {self.budget:,}")
    
    def filter_products(self):
        selected_category = self.category_var.get()
        eco_friendly_only = self.eco_var.get()
        
        filtered_products = []
        
        for product in self.products:
            category_match = selected_category == "Semua" or product["category"] == selected_category
            eco_match = not eco_friendly_only or product["eco_friendly"]
            
            if category_match and eco_match:
                filtered_products.append(product)
                
        self.display_products(filtered_products)
    
    def search_products(self):
        search_term = self.search_entry.get().lower()
        
        if not search_term:
            self.display_products()
            return
            
        search_results = []
        
        for product in self.products:
            if search_term in product["name"].lower() or search_term in product["category"].lower():
                search_results.append(product)
                
        self.display_products(search_results)
    
    def get_cart_categories(self):
        return [item["category"] for item in self.cart]
    
    def show_recommendations(self):
        if not self.cart:
            return
            
        # Get current categories in cart
        cart_categories = self.get_cart_categories()
        
        # Generate recommendations based on requirements
        recommendations = self.generate_recommendations(cart_categories)
        
        if not recommendations:
            return
            
        # Show recommendation window
        rec_window = tk.Toplevel(self.root)
        rec_window.title("Rekomendasi Produk")
        rec_window.geometry("700x400")
        rec_window.configure(bg="white")
        
        # Header
        header_label = tk.Label(rec_window, text="Rekomendasi Produk untuk Anda", 
                              font=("Arial", 14, "bold"), bg="#fb5533", fg="white")
        header_label.pack(fill="x", pady=(0, 20))
        
        # Create scrollable frame for recommendations
        canvas = tk.Canvas(rec_window, bg="white")
        scrollbar = ttk.Scrollbar(rec_window, orient="vertical", command=canvas.yview)
        
        canvas.configure(yscrollcommand=scrollbar.set)
        scrollbar.pack(side="right", fill="y")
        canvas.pack(side="left", fill="both", expand=True)
        
        # Frame inside canvas for recommendations
        inner_frame = tk.Frame(canvas, bg="white")
        canvas.create_window((0, 0), window=inner_frame, anchor="nw")
        
        # Display recommendations
        row = 0
        col = 0
        for product in recommendations:
            product_card = self.create_recommendation_card(inner_frame, product)
            product_card.grid(row=row, column=col, padx=10, pady=10, sticky="nsew")
            
            col += 1
            if col > 2:  # 3 products per row
                col = 0
                row += 1
                
        # Update canvas scroll region
        inner_frame.update_idletasks()
        canvas.config(scrollregion=canvas.bbox("all"))
        
        # Configure grid weights
        for i in range(3):
            inner_frame.columnconfigure(i, weight=1)
    
    def create_recommendation_card(self, parent, product):
        # Card Frame
        card = tk.Frame(parent, bg="white", width=200, height=250, relief="raised", bd=1)
        card.pack_propagate(False)
    
        # Placeholder for product image
        img_placeholder = tk.Frame(card, bg="#e0e0e0", width=180, height=100)
        img_placeholder.pack(pady=(10, 5), padx=10)
    
        try:
            # Ubah base path ke folder 'foto'
            base_path = r"C:\TUGAS INFOR\SEMESTER 2\ALPRO 2\foto"
            img_path = os.path.join(base_path, product["image"])  # Gabungkan path

            if not os.path.exists(img_path):
                raise FileNotFoundError(f"Gambar tidak ditemukan: {img_path}")

            # Load gambar
            img = Image.open(img_path)
        
            # Maintain aspect ratio by calculating new dimensions
            img_width, img_height = img.size
            max_size = 100
        
            # Calculate scaling factor to maintain aspect ratio
            scale_factor = min(max_size / img_width, max_size / img_height)
            new_width = int(img_width * scale_factor)
            new_height = int(img_height * scale_factor)
        
            img = img.resize((new_width, new_height))
            img = ImageTk.PhotoImage(img)

            img_label = tk.Label(img_placeholder, image=img, bg="#e0e0e0")
            img_label.image = img  # Simpan referensi biar nggak hilang
            img_label.pack(expand=True)

        except Exception as e:
            print(f"Error loading image {img_path}: {e}")
            img_label = tk.Label(img_placeholder, text="Gambar tidak ditemukan", bg="#e0e0e0")
            img_label.pack(expand=True, fill="both")

        # Product info
        name_label = tk.Label(card, text=product["name"], font=("Arial", 10, "bold"), bg="white")
        name_label.pack(pady=(5, 0), padx=10, anchor="w")

        price_label = tk.Label(card, text=f"Rp {product['price']:,}", font=("Arial", 10), bg="white", fg="#fb5533")
        price_label.pack(pady=(2, 0), padx=10, anchor="w")

        category_label = tk.Label(card, text=f"Kategori: {product['category']}", font=("Arial", 8), bg="white")
        category_label.pack(pady=(2, 0), padx=10, anchor="w")

        if product["eco_friendly"]:
            eco_label = tk.Label(card, text="Ramah Lingkungan", font=("Arial", 8), bg="#4CAF50", fg="white")
            eco_label.pack(pady=(2, 0), padx=10, anchor="w")

        # Add to cart button
        add_button = tk.Button(card, text="Tambah ke Keranjang", bg="#fb5533", fg="white",
                         command=lambda p=product: self.add_recommendation_to_cart(p))
        add_button.pack(pady=10, padx=10, fill="x")
    
        return card
    
    def add_recommendation_to_cart(self, product):
        self.add_to_cart(product)
    
    def generate_recommendations(self, cart_categories):
        if not self.cart:
            return []
            
        # Find products that meet all criteria:
        # 1. Not already in cart
        # 2. In stock
        # 3. Match categories in cart
        # 4. Match eco-friendly preference if set
        
        cart_product_ids = [item["id"] for item in self.cart]
        recommendations = []
        
        for product in self.products:
            # Skip if already in cart
            if product["id"] in cart_product_ids:
                continue
            
            # Check category constraint
            category_match = any(product["category"] == cat for cat in cart_categories)
                
            if not category_match:
                continue
                
            # Check stock constraint
            if product["stock"] <= 0:
                continue
                
            # Check eco-friendly preference if set
            if self.eco_var.get() and not product["eco_friendly"]:
                continue
                
            recommendations.append(product)
            
        # Return up to 6 recommendations
        return recommendations[:6]

if __name__ == "__main__":
    root = tk.Tk()
    app = ShopeeClone(root)
    root.mainloop()